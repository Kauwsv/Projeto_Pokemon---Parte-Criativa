import os

diretorio = os.path.dirname(__file__)  # Obtém o diretório atual do script

# Listar todos os arquivos no diretório
for nome_arquivo in os.listdir(diretorio):
    caminho_arquivo_antigo = os.path.join(diretorio, nome_arquivo)

    # Verificar se o arquivo é um arquivo e não um diretório
    if os.path.isfile(caminho_arquivo_antigo):
        # Dividir o nome do arquivo em duas partes: o prefixo numérico e a parte após o underscore
        partes = nome_arquivo.split('_')
        if len(partes) == 2 and partes[0].isdigit():
            # Remover os zeros do prefixo numérico
            novo_prefixo = str(int(partes[0]))
            novo_nome_arquivo = novo_prefixo + '_' + partes[1]

            # Criar o caminho do novo arquivo
            caminho_arquivo_novo = os.path.join(diretorio, novo_nome_arquivo)

            # Renomear o arquivo
            os.rename(caminho_arquivo_antigo, caminho_arquivo_novo)
            print(f"Renomeado: {nome_arquivo} -> {novo_nome_arquivo}")
        else:
            print(f"Ignorado: {nome_arquivo}")

print("Concluído!")
